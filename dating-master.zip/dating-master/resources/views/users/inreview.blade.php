@extends('layouts.frontview.master')
@section('content')

  <div id="right_container">
<div class="container">

  <div class="row">

    <div class="col-md-2"></div>

    <div class="col-md-10 showcase">

      <h1>Review Profile</h1>

      <h1>Your Profile Under Review</h1>
 
       <h5>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</h5>

       
</div>


</div>

</div>

</div>

@endsection
